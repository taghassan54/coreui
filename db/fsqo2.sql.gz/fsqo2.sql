-- phpMyAdmin SQL Dump
-- version 4.9.2
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Mar 27, 2020 at 02:56 PM
-- Server version: 10.4.11-MariaDB
-- PHP Version: 7.4.1

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `fsqo2`
--

-- --------------------------------------------------------

--
-- Table structure for table `age_ranges`
--

CREATE TABLE `age_ranges` (
  `id` int(10) UNSIGNED NOT NULL,
  `name` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `deleted_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `age_ranges`
--

INSERT INTO `age_ranges` (`id`, `name`, `created_at`, `updated_at`, `deleted_at`) VALUES
(1, '15 - 30', '2020-03-19 00:01:06', '2020-03-19 00:01:06', NULL),
(2, '30 - 35', '2020-03-19 00:01:21', '2020-03-19 00:01:21', NULL),
(3, '35 - 40', '2020-03-19 00:01:35', '2020-03-19 00:01:35', NULL),
(4, '40 - 45', '2020-03-19 00:01:42', '2020-03-19 00:01:42', NULL);

-- --------------------------------------------------------

--
-- Table structure for table `blog_categories`
--

CREATE TABLE `blog_categories` (
  `id` int(10) UNSIGNED NOT NULL,
  `name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `slug` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `description` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `deleted_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `blog_categories`
--

INSERT INTO `blog_categories` (`id`, `name`, `slug`, `description`, `created_at`, `updated_at`, `deleted_at`) VALUES
(1, 'category 1', NULL, NULL, '2020-03-16 17:21:36', '2020-03-16 17:21:36', NULL),
(2, 'category 2', NULL, NULL, '2020-03-18 09:12:02', '2020-03-18 09:12:02', NULL),
(3, 'category 3', NULL, NULL, '2020-03-18 09:12:11', '2020-03-18 09:12:11', NULL),
(4, 'category 4', NULL, NULL, '2020-03-18 09:12:15', '2020-03-18 09:12:15', NULL),
(5, 'category 5', NULL, NULL, '2020-03-18 09:12:18', '2020-03-18 09:12:18', NULL),
(6, 'category 6', NULL, NULL, '2020-03-18 09:12:26', '2020-03-18 09:12:26', NULL);

-- --------------------------------------------------------

--
-- Table structure for table `blog_comments`
--

CREATE TABLE `blog_comments` (
  `id` int(10) UNSIGNED NOT NULL,
  `post_id` tinyint(3) UNSIGNED NOT NULL,
  `status` enum('pending','publish','spam') COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `deleted_at` timestamp NULL DEFAULT NULL,
  `ip` varchar(15) COLLATE utf8mb4_unicode_ci NOT NULL,
  `user_agent` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `blog_posts`
--

CREATE TABLE `blog_posts` (
  `id` int(10) UNSIGNED NOT NULL,
  `category_id` tinyint(3) UNSIGNED NOT NULL,
  `title` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `description` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `summary` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `content` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `status` enum('draft','publish') COLLATE utf8mb4_unicode_ci NOT NULL,
  `auther_id` int(10) DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `deleted_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `blog_posts`
--

INSERT INTO `blog_posts` (`id`, `category_id`, `title`, `description`, `summary`, `content`, `status`, `auther_id`, `created_at`, `updated_at`, `deleted_at`) VALUES
(1, 1, 'post one', NULL, '<p><strong>post one&nbsp;post</strong> one&nbsp;post one&nbsp;post one&nbsp;post one&nbsp;post one&nbsp;</p><p>post one&nbsp;post one&nbsp;post one&nbsp;post one&nbsp;post one&nbsp;</p><p>&nbsp;</p>', '<p><strong>post one&nbsp;post</strong> one&nbsp;post one&nbsp;post one&nbsp;post one&nbsp;post one&nbsp;</p><p>post one&nbsp;post one&nbsp;post one&nbsp;post one&nbsp;post one&nbsp;</p><p>&nbsp;</p><p>post one&nbsp;post one&nbsp;post one&nbsp;post one&nbsp;post one&nbsp;</p><p>&nbsp;</p><p>post one&nbsp;post one&nbsp;post one&nbsp;post one&nbsp;</p><p>&nbsp;</p><p>post one&nbsp;</p><p><i><strong>post one&nbsp;</strong></i></p>', 'publish', 1, '2020-03-18 09:11:11', '2020-03-18 09:11:11', NULL),
(2, 5, 'Lorem Ipsum', NULL, '<p>Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est laborum.</p>', '<p>Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est laborum.</p><p>Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est laborum.</p><p>Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est laborum.</p><p>Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est laborum.</p><p>Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est laborum.</p>', 'publish', 1, '2020-03-18 09:13:29', '2020-03-18 09:13:29', NULL),
(3, 5, 'Lorem Ipsum 2', NULL, '<p>Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est laborum.</p><p>&nbsp;</p>', '<p><strong>Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est laborum.</strong></p><p><strong>Lorem ipsum </strong>dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est laborum.</p><p>Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est laborum.</p><p>Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est laborum.</p><p>Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est laborum.</p><p>Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est laborum.</p><p>&nbsp;</p>', 'publish', 1, '2020-03-18 09:13:56', '2020-03-18 09:38:45', NULL);

-- --------------------------------------------------------

--
-- Table structure for table `blog_post_tag`
--

CREATE TABLE `blog_post_tag` (
  `id` int(10) UNSIGNED NOT NULL,
  `tag_id` tinyint(3) UNSIGNED NOT NULL,
  `post_id` tinyint(3) UNSIGNED NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `deleted_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `blog_tags`
--

CREATE TABLE `blog_tags` (
  `id` int(10) UNSIGNED NOT NULL,
  `name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `slug` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `categories`
--

CREATE TABLE `categories` (
  `id` int(11) NOT NULL,
  `name` varchar(191) NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NULL DEFAULT NULL,
  `deleted_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `cities`
--

CREATE TABLE `cities` (
  `id` int(10) UNSIGNED NOT NULL,
  `name` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `deleted_at` timestamp NULL DEFAULT NULL,
  `country_id` int(10) UNSIGNED DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `cities`
--

INSERT INTO `cities` (`id`, `name`, `created_at`, `updated_at`, `deleted_at`, `country_id`) VALUES
(1, 'name', '2020-03-18 23:42:28', '2020-03-18 23:58:01', NULL, 1),
(2, 'khartoum', '2020-03-18 23:53:20', '2020-03-18 23:53:20', NULL, 1);

-- --------------------------------------------------------

--
-- Table structure for table `comments`
--

CREATE TABLE `comments` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `commenter_id` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `commenter_type` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `guest_name` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `guest_email` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `commentable_type` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `commentable_id` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `comment` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `approved` tinyint(1) NOT NULL DEFAULT 1,
  `child_id` bigint(20) UNSIGNED DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `comments`
--

INSERT INTO `comments` (`id`, `commenter_id`, `commenter_type`, `guest_name`, `guest_email`, `commentable_type`, `commentable_id`, `comment`, `approved`, `child_id`, `created_at`, `updated_at`) VALUES
(2, '1', 'App\\User', NULL, NULL, 'App\\Models\\Post', '3', 'sdfsdfsdfsdfsd', 1, NULL, '2020-03-18 09:56:12', '2020-03-18 09:56:12'),
(3, '1', 'App\\User', NULL, NULL, 'App\\Models\\Post', '3', 'v good', 1, NULL, '2020-03-18 10:19:48', '2020-03-18 10:19:48'),
(4, '1', 'App\\User', NULL, NULL, 'App\\Models\\Post', '1', 'new comment', 1, NULL, '2020-03-24 09:45:58', '2020-03-24 09:45:58');

-- --------------------------------------------------------

--
-- Table structure for table `contact_info`
--

CREATE TABLE `contact_info` (
  `id` int(10) UNSIGNED NOT NULL,
  `type` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `value` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `deleted_at` timestamp NULL DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `member_id` int(10) UNSIGNED DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `contact_us`
--

CREATE TABLE `contact_us` (
  `id` int(10) UNSIGNED NOT NULL,
  `name` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `email` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `message` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `deleted_at` timestamp NULL DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `contact_us`
--

INSERT INTO `contact_us` (`id`, `name`, `email`, `message`, `deleted_at`, `created_at`, `updated_at`) VALUES
(1, 'tag eldeen hassan', 'taghassan54@gmail.com', 'Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est laborum.', NULL, '2020-03-19 12:45:20', '2020-03-19 12:45:20');

-- --------------------------------------------------------

--
-- Table structure for table `countries`
--

CREATE TABLE `countries` (
  `id` int(10) UNSIGNED NOT NULL,
  `name` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `deleted_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `countries`
--

INSERT INTO `countries` (`id`, `name`, `created_at`, `updated_at`, `deleted_at`) VALUES
(1, 'sudan', '2020-03-18 23:42:20', '2020-03-18 23:42:20', NULL);

-- --------------------------------------------------------

--
-- Table structure for table `events`
--

CREATE TABLE `events` (
  `id` int(10) UNSIGNED NOT NULL,
  `title` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `text` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `date` datetime NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `deleted_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `events`
--

INSERT INTO `events` (`id`, `title`, `text`, `date`, `created_at`, `updated_at`, `deleted_at`) VALUES
(1, 'Lorem Ipsum', 'Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est laborum.', '2020-03-20 00:00:00', '2020-03-19 12:48:27', '2020-03-19 12:48:27', NULL);

-- --------------------------------------------------------

--
-- Table structure for table `experience`
--

CREATE TABLE `experience` (
  `id` int(10) UNSIGNED NOT NULL,
  `job_title` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `from` date NOT NULL,
  `to` date DEFAULT NULL,
  `workplace` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `email` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `deleted_at` timestamp NULL DEFAULT NULL,
  `phone` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `member_id` int(10) UNSIGNED DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `failed_jobs`
--

CREATE TABLE `failed_jobs` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `connection` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `queue` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `payload` longtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `exception` longtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `failed_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `faq`
--

CREATE TABLE `faq` (
  `id` int(10) UNSIGNED NOT NULL,
  `deleted_at` timestamp NULL DEFAULT NULL,
  `answer` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `question` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `faq`
--

INSERT INTO `faq` (`id`, `deleted_at`, `answer`, `created_at`, `updated_at`, `question`) VALUES
(1, NULL, 'Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est laborum.', '2020-03-19 01:36:49', '2020-03-19 01:36:49', '\"Invalid Validation Code\" when trying to validate SSL certificate from Sectigo Certification Authority, unable to resend Approval Email');

-- --------------------------------------------------------

--
-- Table structure for table `footer`
--

CREATE TABLE `footer` (
  `id` int(10) UNSIGNED NOT NULL,
  `address` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `email` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `phone` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `fax` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `lang` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `lat` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `deleted_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `footer`
--

INSERT INTO `footer` (`id`, `address`, `email`, `phone`, `fax`, `lang`, `lat`, `created_at`, `updated_at`, `deleted_at`) VALUES
(1, 'address', 'email@email.com', '0998887970', 'fax', '13', '23', '2020-03-15 22:00:00', NULL, NULL);

-- --------------------------------------------------------

--
-- Table structure for table `fsoo_fields`
--

CREATE TABLE `fsoo_fields` (
  `id` int(10) UNSIGNED NOT NULL,
  `name` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `deleted_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `fsoo_fields`
--

INSERT INTO `fsoo_fields` (`id`, `name`, `created_at`, `updated_at`, `deleted_at`) VALUES
(1, 'Foodsafe', '2020-03-19 00:33:22', '2020-03-19 00:33:22', NULL),
(2, 'Food test', '2020-03-19 00:33:27', '2020-03-19 00:33:27', NULL),
(3, 'Food value', '2020-03-19 00:33:35', '2020-03-19 00:33:35', NULL);

-- --------------------------------------------------------

--
-- Table structure for table `galleries`
--

CREATE TABLE `galleries` (
  `id` int(10) UNSIGNED NOT NULL,
  `title` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `type` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `deleted_at` timestamp NULL DEFAULT NULL,
  `youtube` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `galleries`
--

INSERT INTO `galleries` (`id`, `title`, `type`, `created_at`, `updated_at`, `deleted_at`, `youtube`) VALUES
(1, 'Alan Walker - All Falls Down', 'video', '2020-03-18 21:27:30', '2020-03-18 21:27:30', NULL, 'https://www.youtube.com/watch?v=Tfaq4UTH7P0&list=RDk2qgadSvNyU&index=3'),
(2, 'DJ Khaled - I\'m The One ft. Justin Bieber, Quavo, Chance the Rapper & Lil Wayne', 'video', '2020-03-18 21:43:39', '2020-03-18 21:43:39', NULL, 'https://www.youtube.com/watch?v=weeI1G46q0o&list=RDk2qgadSvNyU&index=5'),
(3, 'Lorem Ipsum', 'img', '2020-03-18 22:18:08', '2020-03-18 22:18:08', NULL, NULL),
(4, 'Clean Bandit feat. Demi Lovato - Solo (DJ Mexx & DJ Karimov Remix)', 'video', '2020-03-18 22:24:52', '2020-03-18 22:24:52', NULL, 'https://www.youtube.com/watch?v=8JnfIa84TnU&list=RDk2qgadSvNyU&index=15'),
(5, '50 Foods That Are Super Healthy', 'img', '2020-03-18 22:26:15', '2020-03-18 22:26:15', NULL, NULL),
(6, 'Foods For Diabetes - What Food Can/Should I Eat?', 'img', '2020-03-18 22:26:44', '2020-03-18 22:26:44', NULL, NULL),
(7, 'Food of Cultures | De wereldkeuken bij jou thuis', 'img', '2020-03-18 22:27:30', '2020-03-18 22:27:30', NULL, NULL),
(8, 'Food of Cultures | De wereldkeuken bij jou thuis', 'img', '2020-03-18 22:27:31', '2020-03-18 22:27:31', NULL, NULL);

-- --------------------------------------------------------

--
-- Table structure for table `join_as`
--

CREATE TABLE `join_as` (
  `id` int(10) UNSIGNED NOT NULL,
  `name` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `deleted_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `libraries`
--

CREATE TABLE `libraries` (
  `id` int(10) UNSIGNED NOT NULL,
  `name` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `deleted_at` timestamp NULL DEFAULT NULL,
  `library_type_id` int(10) UNSIGNED NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `libraries`
--

INSERT INTO `libraries` (`id`, `name`, `created_at`, `updated_at`, `deleted_at`, `library_type_id`) VALUES
(1, 'tag eldeen', '2020-03-26 00:10:29', '2020-03-26 00:10:29', NULL, 1),
(2, 'tag eldeen hassan', '2020-03-26 00:11:29', '2020-03-26 00:11:29', NULL, 1),
(3, 'tag eldeen hassan', '2020-03-26 00:12:06', '2020-03-26 00:12:06', NULL, 1),
(4, 'book one', '2020-03-26 01:47:52', '2020-03-26 01:47:52', NULL, 2);

-- --------------------------------------------------------

--
-- Table structure for table `library_type`
--

CREATE TABLE `library_type` (
  `id` int(10) UNSIGNED NOT NULL,
  `name` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `deleted_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `library_type`
--

INSERT INTO `library_type` (`id`, `name`, `created_at`, `updated_at`, `deleted_at`) VALUES
(1, 'CV', '2020-03-26 00:03:37', '2020-03-26 00:03:37', NULL),
(2, 'Books', '2020-03-26 00:04:00', '2020-03-26 00:04:00', NULL);

-- --------------------------------------------------------

--
-- Table structure for table `media`
--

CREATE TABLE `media` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `model_type` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `model_id` bigint(20) UNSIGNED NOT NULL,
  `collection_name` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `name` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `file_name` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `mime_type` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `disk` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `size` bigint(20) UNSIGNED NOT NULL,
  `manipulations` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_bin NOT NULL CHECK (json_valid(`manipulations`)),
  `custom_properties` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_bin NOT NULL CHECK (json_valid(`custom_properties`)),
  `responsive_images` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_bin NOT NULL CHECK (json_valid(`responsive_images`)),
  `order_column` int(10) UNSIGNED DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `media`
--

INSERT INTO `media` (`id`, `model_type`, `model_id`, `collection_name`, `name`, `file_name`, `mime_type`, `disk`, `size`, `manipulations`, `custom_properties`, `responsive_images`, `order_column`, `created_at`, `updated_at`) VALUES
(1, 'App\\Models\\Slider', 1, 'default', '_1583408652', '_1583408652.png', 'image/png', 'public', 5972, '[]', '[]', '[]', 1, '2020-03-16 17:03:52', '2020-03-16 17:03:52'),
(2, 'App\\Models\\ProgrammAndService', 1, 'default', 'Screenshot (4)', 'Screenshot-(4).png', 'image/png', 'public', 2529147, '[]', '[]', '[]', 2, '2020-03-16 17:07:12', '2020-03-16 17:07:12'),
(3, 'App\\Models\\ProgrammAndService', 5, 'default', 'Screenshot (6)', 'Screenshot-(6).png', 'image/png', 'public', 476040, '[]', '[]', '[]', 3, '2020-03-16 17:09:35', '2020-03-16 17:09:35'),
(5, 'App\\Models\\Gallery', 0, 'default', '5', '5.PNG', 'image/png', 'public', 43322, '[]', '[]', '[]', 5, '2020-03-17 19:22:48', '2020-03-17 19:22:48'),
(7, 'App\\Models\\Gallery', 0, 'default', 'Screenshot (4)', 'Screenshot-(4).png', 'image/png', 'public', 2529147, '[]', '[]', '[]', 6, '2020-03-17 19:26:43', '2020-03-17 19:26:43'),
(8, 'App\\Models\\Gallery', 0, 'default', 'Screenshot (1)', 'Screenshot-(1).png', 'image/png', 'public', 224023, '[]', '[]', '[]', 7, '2020-03-17 19:37:35', '2020-03-17 19:37:35'),
(9, 'App\\Models\\Post', 1, 'default', 'Screenshot (4)', 'Screenshot-(4).png', 'image/png', 'public', 2529147, '[]', '[]', '[]', 8, '2020-03-18 09:11:11', '2020-03-18 09:11:11'),
(10, 'App\\Models\\Post', 2, 'default', 'Screenshot (2)', 'Screenshot-(2).png', 'image/png', 'public', 174357, '[]', '[]', '[]', 9, '2020-03-18 09:13:29', '2020-03-18 09:13:29'),
(11, 'App\\Models\\Post', 2, 'default', 'Screenshot (3)', 'Screenshot-(3).png', 'image/png', 'public', 168565, '[]', '[]', '[]', 10, '2020-03-18 09:13:30', '2020-03-18 09:13:30'),
(12, 'App\\Models\\Post', 2, 'default', 'Screenshot (4)', 'Screenshot-(4).png', 'image/png', 'public', 2529147, '[]', '[]', '[]', 11, '2020-03-18 09:13:30', '2020-03-18 09:13:30'),
(13, 'App\\Models\\Post', 3, 'default', 'Screenshot (8)', 'Screenshot-(8).png', 'image/png', 'public', 453311, '[]', '[]', '[]', 12, '2020-03-18 09:13:56', '2020-03-18 09:13:56'),
(14, 'App\\Models\\Post', 3, 'default', 'Screenshot (9)', 'Screenshot-(9).png', 'image/png', 'public', 1652449, '[]', '[]', '[]', 13, '2020-03-18 09:13:56', '2020-03-18 09:13:56'),
(15, 'App\\Models\\Post', 3, 'default', 'Screenshot (10)', 'Screenshot-(10).png', 'image/png', 'public', 215500, '[]', '[]', '[]', 14, '2020-03-18 09:13:56', '2020-03-18 09:13:56'),
(16, 'App\\Models\\Gallery', 0, 'default', 'Screenshot (9)', 'Screenshot-(9).png', 'image/png', 'public', 1652449, '[]', '[]', '[]', 15, '2020-03-18 10:40:44', '2020-03-18 10:40:44'),
(17, 'App\\Models\\Gallery', 0, 'default', 'Screenshot (10)', 'Screenshot-(10).png', 'image/png', 'public', 215500, '[]', '[]', '[]', 16, '2020-03-18 10:43:10', '2020-03-18 10:43:10'),
(18, 'App\\Models\\Gallery', 0, 'default', 'Screenshot (10)', 'Screenshot-(10).png', 'image/png', 'public', 215500, '[]', '[]', '[]', 17, '2020-03-18 10:43:35', '2020-03-18 10:43:35'),
(19, 'App\\Models\\Gallery', 1, 'default', '59fd831443b3c06b74aeb6ba78e5460763bda329_00', '59fd831443b3c06b74aeb6ba78e5460763bda329_00.jpg', 'image/jpeg', 'public', 30649, '[]', '[]', '[]', 18, '2020-03-18 21:27:30', '2020-03-18 21:27:30'),
(20, 'App\\Models\\Gallery', 2, 'default', 'a94d4fe04a1e11e7af856f4e3523689d-im-the-one-cdq-275-275-1493670493', 'a94d4fe04a1e11e7af856f4e3523689d-im-the-one-cdq-275-275-1493670493.jpg', 'image/jpeg', 'public', 134210, '[]', '[]', '[]', 19, '2020-03-18 21:43:39', '2020-03-18 21:43:39'),
(21, 'App\\Models\\Gallery', 3, 'default', '59fd831443b3c06b74aeb6ba78e5460763bda329_00', '59fd831443b3c06b74aeb6ba78e5460763bda329_00.jpg', 'image/jpeg', 'public', 30649, '[]', '[]', '[]', 20, '2020-03-18 22:18:08', '2020-03-18 22:18:08'),
(22, 'App\\Models\\Gallery', 4, 'default', 'Clean Bandit feat. Demi Lovato - Solo (DJ Mexx & DJ Karimov Remix)', 'Clean-Bandit-feat.-Demi-Lovato---Solo-(DJ-Mexx-&-DJ-Karimov-Remix).jpg', 'image/jpeg', 'public', 110806, '[]', '[]', '[]', 21, '2020-03-18 22:24:52', '2020-03-18 22:24:52'),
(23, 'App\\Models\\Gallery', 5, 'default', 'healthy-eating-ingredients-1296x728-header', 'healthy-eating-ingredients-1296x728-header.jpg', 'image/jpeg', 'public', 186678, '[]', '[]', '[]', 22, '2020-03-18 22:26:15', '2020-03-18 22:26:15'),
(24, 'App\\Models\\Gallery', 6, 'default', 'iStock-10131071761-1', 'iStock-10131071761-1.jpg', 'image/jpeg', 'public', 341445, '[]', '[]', '[]', 23, '2020-03-18 22:26:44', '2020-03-18 22:26:44'),
(25, 'App\\Models\\Gallery', 7, 'default', 'whatsapp-image-2019-10-03-at-19.42.44-1-e1571178781491', 'whatsapp-image-2019-10-03-at-19.42.44-1-e1571178781491.jpeg', 'image/jpeg', 'public', 506996, '[]', '[]', '[]', 24, '2020-03-18 22:27:30', '2020-03-18 22:27:30'),
(26, 'App\\Models\\Gallery', 8, 'default', 'whatsapp-image-2019-10-03-at-19.42.44-1-e1571178781491', 'whatsapp-image-2019-10-03-at-19.42.44-1-e1571178781491.jpeg', 'image/jpeg', 'public', 506996, '[]', '[]', '[]', 25, '2020-03-18 22:27:31', '2020-03-18 22:27:31'),
(27, 'App\\Models\\Partners', 1, 'default', '59fd831443b3c06b74aeb6ba78e5460763bda329_00', '59fd831443b3c06b74aeb6ba78e5460763bda329_00.jpg', 'image/jpeg', 'public', 30649, '[]', '[]', '[]', 26, '2020-03-19 01:16:52', '2020-03-19 01:16:52'),
(28, 'App\\Models\\OurTeam', 1, 'default', 'a94d4fe04a1e11e7af856f4e3523689d-im-the-one-cdq-275-275-1493670493', 'a94d4fe04a1e11e7af856f4e3523689d-im-the-one-cdq-275-275-1493670493.jpg', 'image/jpeg', 'public', 134210, '[]', '[]', '[]', 27, '2020-03-19 01:26:46', '2020-03-19 01:26:46'),
(29, 'App\\Models\\Event', 1, 'default', '59fd831443b3c06b74aeb6ba78e5460763bda329_00', '59fd831443b3c06b74aeb6ba78e5460763bda329_00.jpg', 'image/jpeg', 'public', 30649, '[]', '[]', '[]', 28, '2020-03-19 12:48:27', '2020-03-19 12:48:27'),
(30, 'App\\Models\\Event', 1, 'default', 'a94d4fe04a1e11e7af856f4e3523689d-im-the-one-cdq-275-275-1493670493', 'a94d4fe04a1e11e7af856f4e3523689d-im-the-one-cdq-275-275-1493670493.jpg', 'image/jpeg', 'public', 134210, '[]', '[]', '[]', 29, '2020-03-19 12:48:28', '2020-03-19 12:48:28'),
(31, 'App\\Models\\Event', 1, 'default', 'Clean Bandit feat. Demi Lovato - Solo (DJ Mexx & DJ Karimov Remix)', 'Clean-Bandit-feat.-Demi-Lovato---Solo-(DJ-Mexx-&-DJ-Karimov-Remix).jpg', 'image/jpeg', 'public', 110806, '[]', '[]', '[]', 30, '2020-03-19 12:48:28', '2020-03-19 12:48:28'),
(32, 'App\\Models\\Event', 1, 'default', 'healthy-eating-ingredients-1296x728-header', 'healthy-eating-ingredients-1296x728-header.jpg', 'image/jpeg', 'public', 186678, '[]', '[]', '[]', 31, '2020-03-19 12:48:28', '2020-03-19 12:48:28'),
(33, 'App\\Models\\Event', 1, 'default', 'iStock-10131071761-1', 'iStock-10131071761-1.jpg', 'image/jpeg', 'public', 341445, '[]', '[]', '[]', 32, '2020-03-19 12:48:28', '2020-03-19 12:48:28'),
(34, 'App\\Models\\Event', 1, 'default', 'whatsapp-image-2019-10-03-at-19.42.44-1-e1571178781491', 'whatsapp-image-2019-10-03-at-19.42.44-1-e1571178781491.jpeg', 'image/jpeg', 'public', 506996, '[]', '[]', '[]', 33, '2020-03-19 12:48:28', '2020-03-19 12:48:28'),
(35, 'App\\Models\\Slider', 2, 'default', 'healthy-eating-ingredients-1296x728-header', 'healthy-eating-ingredients-1296x728-header.jpg', 'image/jpeg', 'public', 186678, '[]', '[]', '[]', 34, '2020-03-21 19:18:35', '2020-03-21 19:18:35'),
(36, 'App\\Models\\News', 2, 'default', '6-1-2000x952', '6-1-2000x952.jpg', 'image/jpeg', 'public', 236135, '[]', '[]', '[]', 35, '2020-03-25 23:15:10', '2020-03-25 23:15:10'),
(37, 'App\\Models\\News', 2, 'default', 'istock-60195326-xlarge-web-1200x742', 'istock-60195326-xlarge-web-1200x742.jpg', 'image/jpeg', 'public', 189525, '[]', '[]', '[]', 36, '2020-03-25 23:15:10', '2020-03-25 23:15:10'),
(38, 'App\\Models\\News', 2, 'default', 'mbr-696x464', 'mbr-696x464.jpg', 'image/jpeg', 'public', 52644, '[]', '[]', '[]', 37, '2020-03-25 23:15:10', '2020-03-25 23:15:10'),
(39, 'App\\Models\\News', 2, 'default', 'mbr-1920x1279', 'mbr-1920x1279.jpg', 'image/jpeg', 'public', 478955, '[]', '[]', '[]', 38, '2020-03-25 23:15:10', '2020-03-25 23:15:10'),
(40, 'App\\Models\\News', 1, 'default', 'cropped-6.vue-aerienne-doukki-gel-2000x1199', 'cropped-6.vue-aerienne-doukki-gel-2000x1199.jpg', 'image/jpeg', 'public', 601069, '[]', '[]', '[]', 39, '2020-03-25 23:16:14', '2020-03-25 23:16:14'),
(41, 'App\\Models\\News', 1, 'default', 'cropped-6.vue-aerienne-doukki-gel-2000x11991', 'cropped-6.vue-aerienne-doukki-gel-2000x11991.jpg', 'image/jpeg', 'public', 601069, '[]', '[]', '[]', 40, '2020-03-25 23:16:14', '2020-03-25 23:16:14'),
(42, 'App\\Models\\News', 1, 'default', 'cropped-6.vue-aerienne-doukki-gel-2000x11992', 'cropped-6.vue-aerienne-doukki-gel-2000x11992.jpg', 'image/jpeg', 'public', 601069, '[]', '[]', '[]', 41, '2020-03-25 23:16:14', '2020-03-25 23:16:14'),
(43, 'App\\Models\\Library', 3, 'default', '1584365379766', '1584365379766.pdf', 'application/pdf', 'public', 2766583, '[]', '[]', '[]', 42, '2020-03-26 00:12:06', '2020-03-26 00:12:06'),
(44, 'App\\Models\\Library', 2, 'default', '59fd831443b3c06b74aeb6ba78e5460763bda329_00', '59fd831443b3c06b74aeb6ba78e5460763bda329_00.jpg', 'image/jpeg', 'public', 30649, '[]', '[]', '[]', 43, '2020-03-26 00:26:23', '2020-03-26 00:26:23'),
(45, 'App\\Models\\Library', 1, 'default', '1584365528072', '1584365528072.pdf', 'application/pdf', 'public', 3557767, '[]', '[]', '[]', 44, '2020-03-26 00:26:40', '2020-03-26 00:26:40'),
(46, 'App\\Models\\Library', 4, 'default', '1584365379766', '1584365379766.pdf', 'application/pdf', 'public', 2766583, '[]', '[]', '[]', 45, '2020-03-26 01:47:52', '2020-03-26 01:47:52'),
(47, 'App\\Models\\Partners', 2, 'default', 'a94d4fe04a1e11e7af856f4e3523689d-im-the-one-cdq-275-275-1493670493', 'a94d4fe04a1e11e7af856f4e3523689d-im-the-one-cdq-275-275-1493670493.jpg', 'image/jpeg', 'public', 134210, '[]', '[]', '[]', 46, '2020-03-26 02:26:46', '2020-03-26 02:26:46');

-- --------------------------------------------------------

--
-- Table structure for table `memberships`
--

CREATE TABLE `memberships` (
  `id` int(10) UNSIGNED NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `deleted_at` timestamp NULL DEFAULT NULL,
  `country_id` int(10) UNSIGNED NOT NULL,
  `name` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `gender` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `age_range_id` int(10) UNSIGNED NOT NULL,
  `nationality_id` int(10) UNSIGNED NOT NULL,
  `city_id` int(10) UNSIGNED NOT NULL,
  `district` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `block` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `graduation_date` date NOT NULL,
  `specialization_id` int(10) UNSIGNED NOT NULL,
  `university_id` int(10) UNSIGNED NOT NULL,
  `comments` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `Services_you_like_to_participate` text COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `other_memberships` text COLLATE utf8mb4_unicode_ci NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `migrations`
--

CREATE TABLE `migrations` (
  `id` int(10) UNSIGNED NOT NULL,
  `migration` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `batch` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `migrations`
--

INSERT INTO `migrations` (`id`, `migration`, `batch`) VALUES
(1, '2014_10_12_000000_create_users_table', 1),
(2, '2014_10_12_100000_create_password_resets_table', 1),
(3, '2018_06_30_113500_create_comments_table', 1),
(4, '2019_08_19_000000_create_failed_jobs_table', 1),
(5, '2020_03_12_094036_create_media_table', 1),
(6, '2020_03_12_224546_create_programms_and_services_table', 1),
(7, '2020_03_12_224546_create_sliders_table', 1),
(8, '2020_03_13_015437_create_contact_us_table', 1),
(9, '2020_03_14_083038_create_posts_table', 1),
(10, '2020_03_14_091726_create_events_table', 1),
(11, '2020_03_14_092241_create_blog_categories_table', 1),
(12, '2020_03_14_092241_create_blog_comments_table', 1),
(13, '2020_03_14_092241_create_blog_post_tag_table', 1),
(14, '2020_03_14_092241_create_blog_posts_table', 1),
(15, '2020_03_14_092241_create_blog_tags_table', 1),
(16, '2020_03_14_093308_blog_categories_timestamp', 1),
(17, '2020_03_14_093355_blog_post_tag_timestamp', 1),
(18, '2020_03_14_142133_blog_posts_timestamp', 1),
(19, '2020_03_14_214235_create_footer_table', 1),
(20, '2020_03_16_192048_nullableslug', 2),
(21, '2020_03_17_161620_create_gallery_table', 3),
(22, '2020_03_17_210829_youtube_galleries', 4),
(23, '2020_03_18_110424_blog_posts_slug', 5),
(24, '2020_03_18_115831_allow_commentable_id_to_be_string', 6),
(25, '2020_03_19_013043_create_age_ranges_table', 6),
(26, '2020_03_19_013043_create_cities_table', 6),
(27, '2020_03_19_013043_create_contact_info_table', 6),
(28, '2020_03_19_013043_create_countries_table', 6),
(29, '2020_03_19_013043_create_experience_table', 6),
(30, '2020_03_19_013043_create_fsoo_fields_table', 6),
(31, '2020_03_19_013043_create_memberships_table', 6),
(32, '2020_03_19_013043_create_nationalities_table', 6),
(33, '2020_03_19_013043_create_partners_table', 6),
(34, '2020_03_19_013043_create_specializations_table', 6),
(35, '2020_03_19_013043_create_universities_table', 6),
(36, '2020_03_19_013053_create_foreign_keys', 6),
(37, '2020_03_19_013821_experience_member_id', 7),
(38, '2020_03_19_014408_city_countryid', 8),
(39, '2020_03_19_015922_contact_info_member_id', 9),
(40, '2020_03_19_023522_create_join_as_table', 10),
(41, '2020_03_19_032137_teames', 11),
(42, '2020_03_19_032902_create_privacy_policy_table', 12),
(43, '2020_03_19_033125_privacy_policy_to_text', 13),
(44, '2020_03_19_033504_create_faq_table', 14),
(45, '2020_03_19_153849_create_permission_tables', 15),
(46, '2020_03_26_002636_create_settings_table', 16),
(47, '2020_03_26_003107_change_srting_to_text', 17),
(48, '2020_03_26_020140_create_libraries_table', 18),
(49, '2020_03_26_020140_create_library_type_table', 18),
(50, '2020_03_26_020150_create_foreign_keys', 18);

-- --------------------------------------------------------

--
-- Table structure for table `model_has_permissions`
--

CREATE TABLE `model_has_permissions` (
  `permission_id` bigint(20) UNSIGNED NOT NULL,
  `model_type` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `model_id` bigint(20) UNSIGNED NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `model_has_roles`
--

CREATE TABLE `model_has_roles` (
  `role_id` bigint(20) UNSIGNED NOT NULL,
  `model_type` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `model_id` bigint(20) UNSIGNED NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `nationalities`
--

CREATE TABLE `nationalities` (
  `id` int(10) UNSIGNED NOT NULL,
  `name` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `deleted_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `nationalities`
--

INSERT INTO `nationalities` (`id`, `name`, `created_at`, `updated_at`, `deleted_at`) VALUES
(1, 'sudanese', '2020-03-19 00:03:01', '2020-03-19 00:03:01', NULL),
(2, 'egyptian', '2020-03-19 00:03:19', '2020-03-19 00:03:19', NULL),
(3, 'chinês', '2020-03-19 00:03:33', '2020-03-19 00:03:33', NULL),
(4, 'south sudanese', '2020-03-19 00:29:55', '2020-03-19 00:29:55', NULL);

-- --------------------------------------------------------

--
-- Table structure for table `news`
--

CREATE TABLE `news` (
  `id` int(10) UNSIGNED NOT NULL,
  `title` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `text` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `deleted_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `news`
--

INSERT INTO `news` (`id`, `title`, `text`, `created_at`, `updated_at`, `deleted_at`) VALUES
(1, 'دوكي قيل', 'دوكي قيل تعني التلة الحمراء ، وهي ترمز الى القوة والعلو ، ومنه استمدت شركتنا اسمها لتكون في مقدمة شركات الخدمات اللوجستيه', '2020-03-25 23:14:45', '2020-03-25 23:14:45', NULL),
(2, 'دوكي قيل', 'دوكي قيل تعني التلة الحمراء ، وهي ترمز الى القوة والعلو ، ومنه استمدت شركتنا اسمها لتكون في مقدمة شركات الخدمات اللوجستيه', '2020-03-25 23:15:10', '2020-03-25 23:15:10', NULL);

-- --------------------------------------------------------

--
-- Table structure for table `partners`
--

CREATE TABLE `partners` (
  `id` int(10) UNSIGNED NOT NULL,
  `name` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `position` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `aboute` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `deleted_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `partners`
--

INSERT INTO `partners` (`id`, `name`, `position`, `aboute`, `created_at`, `updated_at`, `deleted_at`) VALUES
(1, 'tag eldeen hassan', 'devolop[er', 'Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est laborum.', '2020-03-19 01:16:52', '2020-03-19 01:16:52', NULL),
(2, 'biko abbas', 'android dev', 'Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est laborum.', '2020-03-26 02:26:46', '2020-03-26 02:26:46', NULL);

-- --------------------------------------------------------

--
-- Table structure for table `password_resets`
--

CREATE TABLE `password_resets` (
  `email` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `token` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `permissions`
--

CREATE TABLE `permissions` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `name` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `guard_name` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `permissions`
--

INSERT INTO `permissions` (`id`, `name`, `guard_name`, `created_at`, `updated_at`) VALUES
(1, 'All Content', 'web', '2020-03-21 19:29:40', '2020-03-21 19:29:40'),
(2, 'Gallery content', 'web', '2020-03-21 19:29:41', '2020-03-21 19:29:41'),
(3, 'Settings', 'web', '2020-03-21 19:29:41', '2020-03-21 19:29:41'),
(4, 'Our Partners content', 'web', '2020-03-21 19:29:41', '2020-03-21 19:29:41'),
(5, 'FSQO Community content', 'web', '2020-03-21 19:29:41', '2020-03-21 19:29:41'),
(6, 'Blogs content', 'web', '2020-03-21 19:29:41', '2020-03-21 19:29:41'),
(7, 'News & Events content', 'web', '2020-03-21 19:29:41', '2020-03-21 19:29:41'),
(8, 'Library & Publications content', 'web', '2020-03-21 19:29:41', '2020-03-21 19:29:41'),
(9, 'About Us content', 'web', '2020-03-21 19:29:41', '2020-03-21 19:29:41');

-- --------------------------------------------------------

--
-- Table structure for table `posts`
--

CREATE TABLE `posts` (
  `id` int(10) UNSIGNED NOT NULL,
  `title` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `text` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `deleted_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `privacy_policy`
--

CREATE TABLE `privacy_policy` (
  `id` int(10) UNSIGNED NOT NULL,
  `privacy_policy` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `deleted_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `privacy_policy`
--

INSERT INTO `privacy_policy` (`id`, `privacy_policy`, `created_at`, `updated_at`, `deleted_at`) VALUES
(1, 'Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est laborum.', '2020-03-19 01:32:39', '2020-03-19 01:32:39', NULL);

-- --------------------------------------------------------

--
-- Table structure for table `programms_and_services`
--

CREATE TABLE `programms_and_services` (
  `id` int(10) UNSIGNED NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `deleted_at` timestamp NULL DEFAULT NULL,
  `title` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `description` text COLLATE utf8mb4_unicode_ci DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `programms_and_services`
--

INSERT INTO `programms_and_services` (`id`, `created_at`, `updated_at`, `deleted_at`, `title`, `description`) VALUES
(1, '2020-03-16 17:07:12', '2020-03-16 17:07:12', NULL, 'Lorem ipsum dolor sit amet, consectetur adipisicing elit.', 'Lorem ipsum dolor sit amet, consectetur adipisicing elit.\r\n\r\nLorem ipsum dolor sit amet, consectetur adipisicing elit.\r\n\r\nLorem ipsum dolor sit amet, consectetur adipisicing elit.\r\n\r\nLorem ipsum dolor sit amet, consectetur adipisicing elit.'),
(2, '2020-03-16 17:07:12', '2020-03-16 17:09:14', '2020-03-16 17:09:14', 'Lorem ipsum dolor sit amet, consectetur adipisicing elit.', 'Lorem ipsum dolor sit amet, consectetur adipisicing elit.\r\n\r\nLorem ipsum dolor sit amet, consectetur adipisicing elit.\r\n\r\nLorem ipsum dolor sit amet, consectetur adipisicing elit.\r\n\r\nLorem ipsum dolor sit amet, consectetur adipisicing elit.'),
(3, '2020-03-16 17:07:12', '2020-03-16 17:09:18', '2020-03-16 17:09:18', 'Lorem ipsum dolor sit amet, consectetur adipisicing elit.', 'Lorem ipsum dolor sit amet, consectetur adipisicing elit.\r\n\r\nLorem ipsum dolor sit amet, consectetur adipisicing elit.\r\n\r\nLorem ipsum dolor sit amet, consectetur adipisicing elit.\r\n\r\nLorem ipsum dolor sit amet, consectetur adipisicing elit.'),
(4, '2020-03-16 17:07:12', '2020-03-16 17:09:09', '2020-03-16 17:09:09', 'Lorem ipsum dolor sit amet, consectetur adipisicing elit.', 'Lorem ipsum dolor sit amet, consectetur adipisicing elit.\r\n\r\nLorem ipsum dolor sit amet, consectetur adipisicing elit.\r\n\r\nLorem ipsum dolor sit amet, consectetur adipisicing elit.\r\n\r\nLorem ipsum dolor sit amet, consectetur adipisicing elit.'),
(5, '2020-03-16 17:09:35', '2020-03-16 17:09:35', NULL, 'Lorem ipsum dolor sit amet, consectetur adipisicing elit.', 'Lorem ipsum dolor sit amet, consectetur adipisicing elit.	Lorem ipsum dolor sit amet, consectetur adipisicing elit.	Lorem ipsum dolor sit amet, consectetur adipisicing elit.');

-- --------------------------------------------------------

--
-- Table structure for table `roles`
--

CREATE TABLE `roles` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `name` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `guard_name` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `roles`
--

INSERT INTO `roles` (`id`, `name`, `guard_name`, `created_at`, `updated_at`) VALUES
(1, 'Website Owner', 'web', '2020-03-21 20:37:06', '2020-03-21 20:37:06'),
(2, 'name', 'web', '2020-03-21 20:45:09', '2020-03-21 20:45:09');

-- --------------------------------------------------------

--
-- Table structure for table `role_has_permissions`
--

CREATE TABLE `role_has_permissions` (
  `permission_id` bigint(20) UNSIGNED NOT NULL,
  `role_id` bigint(20) UNSIGNED NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `role_has_permissions`
--

INSERT INTO `role_has_permissions` (`permission_id`, `role_id`) VALUES
(1, 1),
(1, 2),
(2, 1),
(3, 1),
(3, 2),
(4, 1),
(5, 1),
(6, 1),
(7, 1),
(8, 1),
(9, 1);

-- --------------------------------------------------------

--
-- Table structure for table `settings`
--

CREATE TABLE `settings` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `key` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `value` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `settings`
--

INSERT INTO `settings` (`id`, `key`, `value`, `created_at`, `updated_at`) VALUES
(1, 'Our Programs and Services', 'Lorem ipsum dolor sit amet, consectetur adipisicing elit. Et vero asperiores dolorem placeat blanditiis eligendi iure laborum, eum ratione ullam dolore at assumenda ad inventore alias.', '2020-03-25 22:32:20', '2020-03-25 22:32:20'),
(2, 'FSQO CLUB', 'Lorem ipsum dolor sit amet, consectetur adipiscing elit. Etiam dignissim quis mi eu tristique. Cras et massa erat. Quisque tempus, dolor sit amet ultrices mattis, lectus tellus mattis eros, at eleifend est tortor at eros. Fusce convallis consequat tortor quis blandit.', '2020-03-25 22:34:05', '2020-03-25 22:34:05'),
(3, 'Our Mission', 'Lorem ipsum dolor sit amet, consectetur adipiscing elit. Aliquam tortor purus, suscipit.', '2020-03-25 22:34:45', '2020-03-25 22:34:45'),
(4, 'Our Vision', 'Lorem ipsum dolor sit amet, consectetur adipiscing elit. Aliquam tortor purus, suscipit a accumsan quis, blandit a dolor. Morbi quis purus at ipsum tristique varius sit amet id odio.', '2020-03-25 22:34:59', '2020-03-25 22:34:59');

-- --------------------------------------------------------

--
-- Table structure for table `sliders`
--

CREATE TABLE `sliders` (
  `id` int(10) UNSIGNED NOT NULL,
  `title` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `text` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `type` tinyint(4) NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `deleted_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `sliders`
--

INSERT INTO `sliders` (`id`, `title`, `text`, `type`, `created_at`, `updated_at`, `deleted_at`) VALUES
(1, 'VIDEO SLIDE', 'Slide with youtube video background and color overlay. Title and text are aligned to the left.', 0, '2020-03-16 17:03:52', '2020-03-16 17:03:52', NULL),
(2, 'Lorem Ipsum', 'bottom slider bottom slider bottom slider bottom slider bottom slider bottom slider bottom slider bottom slider bottom slider bottom slider \r\nbottom slider bottom slider bottom slider bottom slider bottom slider \r\nbottom slider bottom slider bottom slider bottom slider bottom slider \r\nbottom slider bottom slider bottom slider bottom slider bottom slider \r\nbottom slider bottom slider bottom slider bottom slider bottom slider', 1, '2020-03-21 19:18:35', '2020-03-21 19:18:35', NULL);

-- --------------------------------------------------------

--
-- Table structure for table `specializations`
--

CREATE TABLE `specializations` (
  `id` int(10) UNSIGNED NOT NULL,
  `name` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `deleted_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `specializations`
--

INSERT INTO `specializations` (`id`, `name`, `created_at`, `updated_at`, `deleted_at`) VALUES
(1, 'Development', '2020-03-19 00:32:10', '2020-03-19 00:32:10', NULL),
(2, 'Professional', '2020-03-19 00:32:37', '2020-03-19 00:32:37', NULL),
(3, 'engineering', '2020-03-19 00:33:00', '2020-03-19 00:33:00', NULL);

-- --------------------------------------------------------

--
-- Table structure for table `teames`
--

CREATE TABLE `teames` (
  `id` int(10) UNSIGNED NOT NULL,
  `name` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `position` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `aboute` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `deleted_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `teames`
--

INSERT INTO `teames` (`id`, `name`, `position`, `aboute`, `created_at`, `updated_at`, `deleted_at`) VALUES
(1, 'tag eldeen hassan', 'devoloper', 'Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim', '2020-03-19 01:26:46', '2020-03-25 22:25:09', NULL);

-- --------------------------------------------------------

--
-- Table structure for table `universities`
--

CREATE TABLE `universities` (
  `id` int(10) UNSIGNED NOT NULL,
  `name` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `deleted_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `universities`
--

INSERT INTO `universities` (`id`, `name`, `created_at`, `updated_at`, `deleted_at`) VALUES
(1, 'nilene', '2020-03-19 00:30:13', '2020-03-19 00:30:13', NULL),
(2, 'sudan', '2020-03-19 00:30:22', '2020-03-19 00:30:22', NULL),
(3, 'khartoum', '2020-03-19 00:30:31', '2020-03-19 00:30:31', NULL),
(4, 'bahri', '2020-03-19 00:30:39', '2020-03-19 00:30:39', NULL);

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `name` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `email` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `email_verified_at` timestamp NULL DEFAULT NULL,
  `password` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `remember_token` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`id`, `name`, `email`, `email_verified_at`, `password`, `remember_token`, `created_at`, `updated_at`) VALUES
(1, 'admin', 'admin@admin.com', NULL, '$2y$10$t/GSIRSmj.aQ/YSPpL5PheS2JhD4azySgxCO28w/OCSJS2nv59ElW', NULL, '2020-03-16 16:58:09', '2020-03-16 16:58:09');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `age_ranges`
--
ALTER TABLE `age_ranges`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `blog_categories`
--
ALTER TABLE `blog_categories`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `blog_categories_slug_unique` (`slug`);

--
-- Indexes for table `blog_comments`
--
ALTER TABLE `blog_comments`
  ADD PRIMARY KEY (`id`),
  ADD KEY `blog_comments_post_id_index` (`post_id`),
  ADD KEY `blog_comments_ip_index` (`ip`);

--
-- Indexes for table `blog_posts`
--
ALTER TABLE `blog_posts`
  ADD PRIMARY KEY (`id`),
  ADD KEY `blog_posts_category_id_index` (`category_id`),
  ADD KEY `blog_posts_status_index` (`status`);

--
-- Indexes for table `blog_post_tag`
--
ALTER TABLE `blog_post_tag`
  ADD PRIMARY KEY (`id`),
  ADD KEY `blog_post_tag_tag_id_index` (`tag_id`),
  ADD KEY `blog_post_tag_post_id_index` (`post_id`);

--
-- Indexes for table `blog_tags`
--
ALTER TABLE `blog_tags`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `blog_tags_slug_unique` (`slug`);

--
-- Indexes for table `categories`
--
ALTER TABLE `categories`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `cities`
--
ALTER TABLE `cities`
  ADD PRIMARY KEY (`id`),
  ADD KEY `cities_country_id_foreign` (`country_id`);

--
-- Indexes for table `comments`
--
ALTER TABLE `comments`
  ADD PRIMARY KEY (`id`),
  ADD KEY `comments_commenter_id_commenter_type_index` (`commenter_id`,`commenter_type`),
  ADD KEY `comments_commentable_type_commentable_id_index` (`commentable_type`,`commentable_id`),
  ADD KEY `comments_child_id_foreign` (`child_id`);

--
-- Indexes for table `contact_info`
--
ALTER TABLE `contact_info`
  ADD PRIMARY KEY (`id`),
  ADD KEY `contact_info_member_id_foreign` (`member_id`);

--
-- Indexes for table `contact_us`
--
ALTER TABLE `contact_us`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `countries`
--
ALTER TABLE `countries`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `events`
--
ALTER TABLE `events`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `experience`
--
ALTER TABLE `experience`
  ADD PRIMARY KEY (`id`),
  ADD KEY `experience_member_id_foreign` (`member_id`);

--
-- Indexes for table `failed_jobs`
--
ALTER TABLE `failed_jobs`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `faq`
--
ALTER TABLE `faq`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `footer`
--
ALTER TABLE `footer`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `fsoo_fields`
--
ALTER TABLE `fsoo_fields`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `galleries`
--
ALTER TABLE `galleries`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `join_as`
--
ALTER TABLE `join_as`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `libraries`
--
ALTER TABLE `libraries`
  ADD PRIMARY KEY (`id`),
  ADD KEY `libraries_library_type_id_foreign` (`library_type_id`);

--
-- Indexes for table `library_type`
--
ALTER TABLE `library_type`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `media`
--
ALTER TABLE `media`
  ADD PRIMARY KEY (`id`),
  ADD KEY `media_model_type_model_id_index` (`model_type`,`model_id`);

--
-- Indexes for table `memberships`
--
ALTER TABLE `memberships`
  ADD PRIMARY KEY (`id`),
  ADD KEY `memberships_country_id_foreign` (`country_id`),
  ADD KEY `memberships_age_range_id_foreign` (`age_range_id`),
  ADD KEY `memberships_nationality_id_foreign` (`nationality_id`),
  ADD KEY `memberships_city_id_foreign` (`city_id`),
  ADD KEY `memberships_specialization_id_foreign` (`specialization_id`),
  ADD KEY `memberships_university_id_foreign` (`university_id`);

--
-- Indexes for table `migrations`
--
ALTER TABLE `migrations`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `model_has_permissions`
--
ALTER TABLE `model_has_permissions`
  ADD PRIMARY KEY (`permission_id`,`model_id`,`model_type`),
  ADD KEY `model_has_permissions_model_id_model_type_index` (`model_id`,`model_type`);

--
-- Indexes for table `model_has_roles`
--
ALTER TABLE `model_has_roles`
  ADD PRIMARY KEY (`role_id`,`model_id`,`model_type`),
  ADD KEY `model_has_roles_model_id_model_type_index` (`model_id`,`model_type`);

--
-- Indexes for table `nationalities`
--
ALTER TABLE `nationalities`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `news`
--
ALTER TABLE `news`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `partners`
--
ALTER TABLE `partners`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `password_resets`
--
ALTER TABLE `password_resets`
  ADD KEY `password_resets_email_index` (`email`);

--
-- Indexes for table `permissions`
--
ALTER TABLE `permissions`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `posts`
--
ALTER TABLE `posts`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `privacy_policy`
--
ALTER TABLE `privacy_policy`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `programms_and_services`
--
ALTER TABLE `programms_and_services`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `roles`
--
ALTER TABLE `roles`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `role_has_permissions`
--
ALTER TABLE `role_has_permissions`
  ADD PRIMARY KEY (`permission_id`,`role_id`),
  ADD KEY `role_has_permissions_role_id_foreign` (`role_id`);

--
-- Indexes for table `settings`
--
ALTER TABLE `settings`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `sliders`
--
ALTER TABLE `sliders`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `specializations`
--
ALTER TABLE `specializations`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `teames`
--
ALTER TABLE `teames`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `universities`
--
ALTER TABLE `universities`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `users_email_unique` (`email`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `age_ranges`
--
ALTER TABLE `age_ranges`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT for table `blog_categories`
--
ALTER TABLE `blog_categories`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;

--
-- AUTO_INCREMENT for table `blog_comments`
--
ALTER TABLE `blog_comments`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `blog_posts`
--
ALTER TABLE `blog_posts`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT for table `blog_post_tag`
--
ALTER TABLE `blog_post_tag`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `blog_tags`
--
ALTER TABLE `blog_tags`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `categories`
--
ALTER TABLE `categories`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `cities`
--
ALTER TABLE `cities`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `comments`
--
ALTER TABLE `comments`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT for table `contact_info`
--
ALTER TABLE `contact_info`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `contact_us`
--
ALTER TABLE `contact_us`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `countries`
--
ALTER TABLE `countries`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `events`
--
ALTER TABLE `events`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `experience`
--
ALTER TABLE `experience`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `failed_jobs`
--
ALTER TABLE `failed_jobs`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `faq`
--
ALTER TABLE `faq`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `footer`
--
ALTER TABLE `footer`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `fsoo_fields`
--
ALTER TABLE `fsoo_fields`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT for table `galleries`
--
ALTER TABLE `galleries`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=9;

--
-- AUTO_INCREMENT for table `join_as`
--
ALTER TABLE `join_as`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `libraries`
--
ALTER TABLE `libraries`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT for table `library_type`
--
ALTER TABLE `library_type`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `media`
--
ALTER TABLE `media`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=48;

--
-- AUTO_INCREMENT for table `memberships`
--
ALTER TABLE `memberships`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `migrations`
--
ALTER TABLE `migrations`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=51;

--
-- AUTO_INCREMENT for table `nationalities`
--
ALTER TABLE `nationalities`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT for table `news`
--
ALTER TABLE `news`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `partners`
--
ALTER TABLE `partners`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `permissions`
--
ALTER TABLE `permissions`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=10;

--
-- AUTO_INCREMENT for table `posts`
--
ALTER TABLE `posts`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `privacy_policy`
--
ALTER TABLE `privacy_policy`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `programms_and_services`
--
ALTER TABLE `programms_and_services`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- AUTO_INCREMENT for table `roles`
--
ALTER TABLE `roles`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `settings`
--
ALTER TABLE `settings`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT for table `sliders`
--
ALTER TABLE `sliders`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `specializations`
--
ALTER TABLE `specializations`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT for table `teames`
--
ALTER TABLE `teames`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `universities`
--
ALTER TABLE `universities`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- Constraints for dumped tables
--

--
-- Constraints for table `cities`
--
ALTER TABLE `cities`
  ADD CONSTRAINT `cities_country_id_foreign` FOREIGN KEY (`country_id`) REFERENCES `countries` (`id`) ON DELETE CASCADE;

--
-- Constraints for table `comments`
--
ALTER TABLE `comments`
  ADD CONSTRAINT `comments_child_id_foreign` FOREIGN KEY (`child_id`) REFERENCES `comments` (`id`) ON DELETE CASCADE;

--
-- Constraints for table `contact_info`
--
ALTER TABLE `contact_info`
  ADD CONSTRAINT `contact_info_member_id_foreign` FOREIGN KEY (`member_id`) REFERENCES `memberships` (`id`) ON DELETE CASCADE;

--
-- Constraints for table `experience`
--
ALTER TABLE `experience`
  ADD CONSTRAINT `experience_member_id_foreign` FOREIGN KEY (`member_id`) REFERENCES `memberships` (`id`) ON DELETE CASCADE;

--
-- Constraints for table `libraries`
--
ALTER TABLE `libraries`
  ADD CONSTRAINT `libraries_library_type_id_foreign` FOREIGN KEY (`library_type_id`) REFERENCES `library_type` (`id`);

--
-- Constraints for table `memberships`
--
ALTER TABLE `memberships`
  ADD CONSTRAINT `memberships_age_range_id_foreign` FOREIGN KEY (`age_range_id`) REFERENCES `age_ranges` (`id`),
  ADD CONSTRAINT `memberships_city_id_foreign` FOREIGN KEY (`city_id`) REFERENCES `cities` (`id`),
  ADD CONSTRAINT `memberships_country_id_foreign` FOREIGN KEY (`country_id`) REFERENCES `countries` (`id`),
  ADD CONSTRAINT `memberships_nationality_id_foreign` FOREIGN KEY (`nationality_id`) REFERENCES `nationalities` (`id`),
  ADD CONSTRAINT `memberships_specialization_id_foreign` FOREIGN KEY (`specialization_id`) REFERENCES `specializations` (`id`),
  ADD CONSTRAINT `memberships_university_id_foreign` FOREIGN KEY (`university_id`) REFERENCES `universities` (`id`);

--
-- Constraints for table `model_has_permissions`
--
ALTER TABLE `model_has_permissions`
  ADD CONSTRAINT `model_has_permissions_permission_id_foreign` FOREIGN KEY (`permission_id`) REFERENCES `permissions` (`id`) ON DELETE CASCADE;

--
-- Constraints for table `model_has_roles`
--
ALTER TABLE `model_has_roles`
  ADD CONSTRAINT `model_has_roles_role_id_foreign` FOREIGN KEY (`role_id`) REFERENCES `roles` (`id`) ON DELETE CASCADE;

--
-- Constraints for table `role_has_permissions`
--
ALTER TABLE `role_has_permissions`
  ADD CONSTRAINT `role_has_permissions_permission_id_foreign` FOREIGN KEY (`permission_id`) REFERENCES `permissions` (`id`) ON DELETE CASCADE,
  ADD CONSTRAINT `role_has_permissions_role_id_foreign` FOREIGN KEY (`role_id`) REFERENCES `roles` (`id`) ON DELETE CASCADE;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
